import React from 'react';

import logo from './logo.svg';
import './App.css';

import  {BrowserRouter as Router,Redirect ,Route,useHistory } from 'react-router-dom'
import login from './Components/Login'
import dashboard from './Components/Dashboard'
import join from './Components/Join'
function App() {
  return (
   
      <div>
          <Router>
          <Route exact path='/'>
          <Redirect to="/Login" />
       </Route>
          <Route exact path="/Login" component={login}></Route>
          <Route exact path="/dashboard" component={dashboard}></Route>
          <Route exact path="/join" component={join}></Route>
         </Router>
         
      </div>
  
  )
}

export default App;
