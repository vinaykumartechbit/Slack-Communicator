import React from 'react'
import LoginImage from './loginImage.png'
import { Button,Modal,Form } from 'react-bootstrap'
import {br} from 'react-router-dom';
class Login extends React.Component{
   
    constructor(props){
        super(props);
       
        this.state = { 
         Username:'',
         Password:'',
         errors:'',
         Invalid:false
        }
        this.handleChange = this.handleChange.bind(this);
      }
      handleValidation()
      {debugger
          let errors = {};
          let formIsValid = true;
          if(this.state.Username=="" || this.state.Username==undefined)
          { 
  
          errors["Username"] = "Username  Cannot be empty";
          formIsValid=false;
      
          }
          if(this.state.Password=="" || this.state.Password==undefined)
          { 
  
          errors["Password"] = "Password  Cannot be empty";
          formIsValid=false;
        
          }
          this.setState({errors: errors});
          return formIsValid;
      }
      handleChange(event) {
      
          let name = event.target.name;
        if(name=="Username")
        this.setState({Username: event.target.value});
        if(name=="Password")
        this.setState({Password: event.target.value});
    console.log(this.state.Username)
      }
      
      handleSubmit(e)
      {
        e.preventDefault();
        if(this.handleValidation())
        {
          debugger
        var body={
            Username:this.state.Username,
            Password:this.state.Password

          }
          
        fetch("https://localhost:44364/api/Members/Login", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=utf-8'},
            body: JSON.stringify(body),
        }).then(res => res.json())
        .then((data) => {
          debugger
      
          if(data.length>0)
          { 
localStorage.setItem("memberId",data[0].memberId);
localStorage.setItem("memberName",this.state.Username);
            window.location.href="http://localhost:3000/dashboard"
          }
          else
          {
this.setState({Invalid:true});
          }
        })
        .catch(console.log)
      }
    }
      render(){
       debugger
        return(
         <div>
          <div className="wrapper fadeInDown">
  <div id="formContent">

    <div>
    { <img src={LoginImage} style={{height: "50px",width: "50px",marginBottom: "35px",marginTop : "35px"}}  id="icon" alt="User Icon" />}
    </div>
 


   
    <form>
      <input type="text" id="login" className="fadeIn second" value={this.state.Username}  onChange={this.handleChange}  name="Username" placeholder="username"/>
      <span style={{color: "red"}}>{this.state.errors["Username"]}</span>
      <input type="text" id="password" className="fadeIn third" onChange={this.handleChange} value={this.state.Password} name="Password" placeholder="password"/>
      <span style={{color: "red"}}>{this.state.errors["Password"]}</span>
{this.state.Invalid &&  <span style={{color: "red"}}>Username or Password did not matched.</span>}
      
    <br></br>  <br></br>
      <button style={{marginTop: "35px",marginBottom:"10px"}} onClick={(e) => this.handleSubmit(e)} type="button" class="btn btn-primary">Login</button>
    </form>


   

  </div>
</div>
         </div>
        )
        }
  }
export default Login;