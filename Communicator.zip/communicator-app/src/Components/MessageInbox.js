import React from 'react'
import { Button,Modal,Form } from 'react-bootstrap'
import equal from 'fast-deep-equal'
import {  BsFillCaretRightFill }  from "react-icons/bs";
import { red } from '@material-ui/core/colors';
import { FcPortraitMode } from "react-icons/fc";
import moment from 'moment';
import Chip from '@material-ui/core/Chip';
class MessageInbox extends React.Component{

    constructor(props){
        super(props);
       this.state={
           messageList:[],
           memberId:'',
           message:'',
           intervalId:'',
          
       }

       this.handleChange = this.handleChange.bind(this);
       this.handleSubmit= this.handleSubmit.bind(this);
    }
    componentDidMount() {
        
      
    }
    componentDidUpdate(prevProps)
    { 
        
        debugger;
        var Id=localStorage.getItem("memberId");
      
        if(this.props.memberId)
        {
        if(!equal(this.props.memberId, prevProps.memberId)) // Check if it's a new user, you can also use some unique property, like the ID  (this.props.user.id !== prevProps.user.id)
        {    
        this.setState({memberId:Id});
        this.updateMessage(this.props.memberId,'member');
        this.startInterval(this.props.memberId,'member');
        }

        }
        else{
            if(!equal(this.props.channelId, prevProps.channelId)) // Check if it's a new user, you can also use some unique property, like the ID  (this.props.user.id !== prevProps.user.id)
        { 
            this.setState({channelId:Id.toString()});
            this.updateMessage(this.props.channelId,'channel');
            this.startInterval(this.props.channelId,'channel');
        }}
    }

        updateMessage(id,source)
        {
            debugger
        var body={
           SentBy:localStorage.getItem("memberId"),
           SentTo:id,
           msgsource:source
        }
        fetch("https://localhost:44364/api/MembersInbox/GetMessages", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=utf-8'},
            body: JSON.stringify(body),
        }).then(res => res.json())
        .then((data) => {
          debugger
        this.setState({messageList:data})
        
        })
        .catch(console.log)

        }


      handleChange(event) {
          debugger
          
            this.setState({message: event.target.value});
            console.log(this.state.message)
          
   
  }

  handleKeyPress = (event) => {
    if(event.key === 'Enter'){
     this.handleSubmit(event);
    }
  }

  startInterval= (id,source) =>
  {
      debugger
    clearInterval(this.state.intervalId)
    this.state.intervalId = setInterval(() => {
    this.updateMessage(id,source);
    }, 10000);
  }
        handleSubmit(e)
        { 

            e.preventDefault();
           var id=0;
           var source="";
           if(this.props.channelId)
           {
               id= parseInt(this.props.channelId);
               source="channel"
           }
           else{
               id=parseInt(this.props.memberId);
               source="member";
           }
debugger
          if(this.state.message.trim()!='')
          {
            var body={
                message:this.state.message,
                sentTo:id,
                sentBy:localStorage.getItem("memberId"),
                msgsource:source,
                workspaceId:this.props.workSpaceId
            }
            debugger
            fetch("https://localhost:44364/api/MembersInbox/SaveMessages", {
                method: 'POST',
                headers: { 'Content-Type': 'application/json; charset=utf-8'},
                body: JSON.stringify(body),
            }).then(res => res.json())
            .then((data) => {
              debugger

             this.startInterval(id,source);
             this.updateMessage(id,source);
             this.setState({message:''})
             
            })
            .catch(console.log)
           
        }
    }
    render(){   
var messagedate='';
this.items=[];
        this.items = this.state.messageList.map((item) =>
        
     <div>
         <div className="row">
         <div className="col-5"></div>
             <div className="col-2">
            {item.messageDate&& <Chip label={moment(item.messageDate).format('MMMM-D')} variant="outlined" />}
             
             </div>
             <div className="col-5"></div>
            <div className="col-1"> 
      
           <FcPortraitMode style={{height:"50px",width:"50px"}}></FcPortraitMode>
            </div>
            <div className="col-9"> 
            <b className="MessageSender" style={{fontSize:"15px",paddingRight:"15px"}}>{item.senderName} </b> 
           <span  style={{fontSize:"12px"}}> {moment(item.sentDate).format("hh:mm a")}</span><br></br>
           
            <span  >{item.message}</span>
            </div>
         

           
         </div>
      
      
         
     </div>

      );
     
      return(



        <div className=''>
{this.items}

<div className="fixed-bottom ">
  
<div className="row">
    <div className="col-lg-11">
    <textarea style={{marginLeft:'57px', width:'95%'}} onKeyPress={this.handleKeyPress}  name="message"onChange={this.handleChange} value={this.state.message}  class="form-control"></textarea>
    </div>
    <div className="col-lg-1">
    <div><BsFillCaretRightFill style={{height:'65px', width:'90px',marginLeft:'-35px'}}    onClick={this.handleSubmit} /></div> 
    </div>
</div>



</div>
      </div>
  


      )
      }
}
export default MessageInbox;