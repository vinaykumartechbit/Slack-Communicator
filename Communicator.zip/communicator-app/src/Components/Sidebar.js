import React from 'react'
import { Button,Modal,Form } from 'react-bootstrap'
import { Multiselect } from 'multiselect-react-dropdown';
import equal from 'fast-deep-equal'
import List from '@material-ui/core/List'
import ListItem from '@material-ui/core/ListItem'
import ListItemText from '@material-ui/core/ListItemText'
import { ProSidebar,SidebarHeader, SidebarFooter, SidebarContent, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import 'react-pro-sidebar/dist/css/styles.css';
import {  BiBadge }  from "react-icons/bi";

class Sidebar extends React.Component{

    constructor(props){
        super(props);
       this.state={
           members:[],
           Channels:[],
           WorkSpaces:[],
           memberId:'',
           showInbox:false,
           showHideWorkSpacePopup:false,
           showHideChannelPopup:false,
           ChannelName:'',
           Channelid:'',
           selectedValue:[],
           options: [],
           errors:[],
           WorkSpaceName:'',
           WorkSpaceId:'',
           showHideInvitePeaplePopup:false,
           InvitePeaple:''
       }
       this.handleChange=this.handleChange.bind(this);
       this.onChangeValue = this.onChangeValue.bind(this);
       this.onSelect=this.onSelect.bind(this);
       this.onRemove=this.onRemove.bind(this);
       this.handleChannelSubmit=this.handleChannelSubmit.bind(this);
       this.handleSaveWorkSpace=this.handleSaveWorkSpace.bind(this);
       this.handleInvitePeeaple=this.handleInvitePeeaple.bind(this);
    }


    componentDidMount() {
       
       this.getWorkSpaces();
      }
      componentDidUpdate(prevProps)
      { debugger
        if(!equal(this.props.workSpaceId, prevProps.workSpaceId)) // Check if it's a new user, you can also use some unique property, like the ID  (this.props.user.id !== prevProps.user.id)
        {    
        this.setState({workSpaceId:this.props.workSpaceId});
      
        }

        
      }  

      handleChange = event => {
   debugger
        this.setState({ [event.target.name]: event.target.value });
      
      };

      HandleActiveRadio=item => {
       
      };

      onChangeValue(event) {
        console.log(event.target.value);
      }

getWorkSpaces()
{ 
  
  fetch("https://localhost:44364/api/workspace/GetWorkSpace")
.then(response => response.json())
.then(data => {
  
   this.setState({WorkSpaces: data});
   this.setState({workSpaceId:data[0].workSpaceId})
     
  })
.catch(error => this.setState({ error, isLoading: false }));

}


      getChannels(id)
      {
var body={
  workspaceid:16
}
return   fetch("https://localhost:44364/api/channel/getchannel", {
        method: 'Post',
        headers: { 'Content-Type': 'application/json; charset=utf-8'},
        body: JSON.stringify(body),
    })
        .then(response => response.json())
        .then(data => {
          this.setState({Channels: data});
          return data;
          })
        .catch(error => this.setState({ error, isLoading: false }));
      }


      getMembers()
      {
        fetch("https://localhost:44364/api/members/get")
        .then(response => response.json())
        .then(data => {
          this.setState({members: data});
           this.state.members.map((item) =>
           this.state.options.push({name: item.memberName, id: item.memberId}),
          
           );
           
          })
        .catch(error => this.setState({ error, isLoading: false }));
      }


      handleValidation(){

        let errors = {};
        let formIsValid = true;

        if(this.state.ChannelName=="" || this.state.ChannelName==undefined)
        {
          errors["channelName"] = "Channel Name Cannot be empty";
          formIsValid=false;
        }

        if(this.state.selectedValue.length==0)
        {
          errors["selectedValue"] = "please select atleast one member";
          formIsValid=false;
        }
        this.setState({errors: errors});
        return formIsValid;
      }

      handleInvitePeapleValidation()
      {
debugger
        let errors = {};
        let formIsValid = true;
        var pattern = "";
        if (this.state.InvitePeaple !== "undefined") {
          var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);        
          if (!pattern.test(this.state.InvitePeaple)) {
            formIsValid = false;
            errors["InvitePeaple"] = "Please enter valid email address.";
        
          }
        
        }
        this.setState({errors: errors});
        return formIsValid;
      }
    
      handleChannelSubmit(e)
      {

        e.preventDefault();
        if(this.handleValidation())
        { 
         
        const EmployeeIds=[];
        this.state.selectedValue.map((item, key) => (

EmployeeIds.push(item.id)
        ));
        var body={
          ChannelId:0,
          ChannelName:this.state.ChannelName,
          MemberList:EmployeeIds.toString(),
          workspaceid:this.state.workSpaceId
        }
        debugger
        fetch("https://localhost:44364/api/channel/SaveChannel", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=utf-8'},
            body: JSON.stringify(body),
        }).then(res => res.json())
        .then((data) => {
          debugger
          this.setState({ChannelName:''});
          this.setState({selectedValue:''}); 
          this.setState({ showHideChannelPopup: false })
          this.getWorkSpaces();
        })
        .catch(console.log)
      }
      }

      handleModalShowHide() {
          this.setState({ showHideWorkSpacePopup: !this.state.showHideWorkSpacePopup })
      }
      
      handleshowHideInvitePeaplePopup(items,id)
      { debugger
        this.setState({WorkSpaceId:id})
        this.setState({ showHideInvitePeaplePopup: !this.state.showHideInvitePeaplePopup })
      }
      handleChannelModalshowHide(items,id)
      {
        debugger
        if(items!=undefined)
        {
        if(items.length>0) 
        {
          if(this.state.options.length==0)
          {
        items.map((item) =>
        this.state.options.push({name: item.memberName, id: item.memberId}),
        );
        }
      }
        this.setState({workSpaceId:id})
         
      }
      this.setState({ showHideChannelPopup: !this.state.showHideChannelPopup })
    }
      onSelect(selectedList, selectedItem) {
        debugger
        this.setState({selectedValue:selectedList});
    }
     
    onRemove(selectedList, removedItem) {
      this.setState({selectedValue:selectedList});
    }


    handleSaveWorkSpace(e)
    {
      debugger

      var body={
        
        WorkSpaceName:this.state.WorkSpaceName
       
       
      }
      fetch("https://localhost:44364/api/WorkSpace/SaveWorkSpace", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8'},
        body: JSON.stringify(body),
    }).then(res => res.json())
    .then((data) => {
     debugger
     this.setState({WorkSpaceName:''});
     this.setState({ showHideWorkSpacePopup: false })
    })
    .catch(console.log)
    }
    handleInvitePeeaple(e)
    {
      debugger
      console.log(this.state.InvitePeaple)
      e.preventDefault();
      var a=this.handleInvitePeapleValidation()
if(this.handleInvitePeapleValidation())
{   var Id=localStorage.getItem("memberId");
      var body={
        
        email:this.state.InvitePeaple,
        workSpaceId:this.state.WorkSpaceId,
       senderId:Id
      }
      fetch("https://localhost:44364/api/WorkSpace/SendEmail", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8'},
        body: JSON.stringify(body),
    }).then(res => res.json())
    .then((data) => {
     debugger
     this.setState({InvitePeaple:''});
     //this.setState({ handleshowHideInvitePeaplePopup: false })
    })
    .catch(console.log)

    }
  }
    render(){
      this.WorkSpace=[];
       
this.WorkSpace=this.state.WorkSpaces.map((item,index) =>{
  return(
    
<div >
<ProSidebar >
<Menu iconShape="square">
<div>
<SubMenu  title={item.workSpaceName} >
{/* <div> <a  onClick={() => this.props.handleUserMessges(item,item.workSpaceId)}>{item.workSpaceName}</a> </div> */}



          <SubMenu  title="Channel" >
     

             {
           item.channelItems.map((subitem, i) => {
                  return (
                      <li onClick={() => this.props.handleUserMessges(subitem,item.workSpaceId)} style={{cursor:"Pointer"}} ># {subitem.channelName}</li>
                  )
                })

              }
              
           <span onClick={(e)=>this.handleChannelModalshowHide(item.memberItems,item.workSpaceId)} class="primary" style={{cursor:"Pointer"}}>+ Add New Channel
            <i class="fa fa-caret-down"></i>
           </span>
              </SubMenu>

          <SubMenu  title="Direct Message" >
         
          {
        item.memberItems.map((subitem, i) => {
         
               return (
                 <li onClick={() => this.props.handleUserMessges(subitem,item.workSpaceId)} style={{cursor:"Pointer"}}>{subitem.memberName}</li>
                 )
             })

           }
           
           </SubMenu>

           <span onClick={(e)=>this.handleshowHideInvitePeaplePopup(item.memberItems,item.workSpaceId)} class="primary" style={{cursor:"Pointer"}}> + Invite Peaple
            <i class="fa fa-caret-down"></i>
           </span>
<br></br>
           <span onClick={(e)=>this.handleModalShowHide()} class="primary" style={{cursor:"Pointer"}}>+ Add New WorkSpace
            <i class="fa fa-caret-down"></i>
           </span>

          
 </SubMenu>
      </div>
         </Menu>
         </ProSidebar>
</div>
)
}
 );

      return(      
  <div >
    <div style={{height:'100%'}}> {this.WorkSpace}</div>
   

 <Modal   show={this.state.showHideInvitePeaplePopup}>
<Modal.Header closeButton onClick={() => this.handleshowHideInvitePeaplePopup()}>
<Modal.Title>Invite peaple to this WorkSpace</Modal.Title>
</Modal.Header>
<Modal.Body>
<Form>


<Form.Group controlId="formTitle">
<Form.Label>Email Address:</Form.Label>
<textarea    name="InvitePeaple"onChange={this.handleChange} value={this.state.InvitePeaple}  class="form-control"></textarea>
<span style={{color: "red"}}>{this.state.errors["InvitePeaple"]}</span>
</Form.Group>

<button onClick={(e) => this.handleInvitePeeaple(e)} type="button" class="btn btn-primary">Invite</button>



</Form>
</Modal.Body>

</Modal>
 
<Modal show={this.state.showHideWorkSpacePopup}>
<Modal.Header closeButton onClick={() => this.handleModalShowHide()}>
<Modal.Title>Add Workspace</Modal.Title>
</Modal.Header>
<Modal.Body>
<Form>


<Form.Group controlId="formTitle">
<Form.Label>Workspace Name</Form.Label>
<Form.Control type="text" name="WorkSpaceName" value={this.state.WorkSpaceName}  onChange={this.handleChange} placeholder="Enter Workspace Name" />    
</Form.Group>


<button onClick={(e) => this.handleSaveWorkSpace(e)} type="button" class="btn btn-primary">Add</button>



</Form>
</Modal.Body>

</Modal>
 
<Modal show={this.state.showHideChannelPopup}>
<Modal.Header closeButton onClick={() => this.handleChannelModalshowHide()}>
<Modal.Title>Add New Channel</Modal.Title>
</Modal.Header>
<Modal.Body>

<Form>
<Form.Label> Select  Member</Form.Label>
<Multiselect style={{padding: 0}}
options={this.state.options} // Options to display in the dropdown
selectedValues={this.state.selectedValue} // Preselected value to persist in dropdown
onSelect={this.onSelect} // Function will trigger on select event
onRemove={this.onRemove} // Function will trigger on remove event
displayValue="name" // Property name to display in the dropdown options
/>
<span style={{color: "red"}}>{this.state.errors["selectedValue"]}</span>
<Form.Group controlId="formTitle">
<Form.Label> Channel Name</Form.Label>
<Form.Control type="text" name="ChannelName"  value={this.state.ChannelName}  onChange={this.handleChange} placeholder="Enter  Channel Name" />    
<span style={{color: "red"}}>{this.state.errors["channelName"]}</span>
</Form.Group>

<button onClick={(e) => this.handleChannelSubmit(e)} type="button" class="btn btn-primary">Add</button>




</Form>
</Modal.Body>

</Modal>
</div>
     
      )
      }
  }


export default Sidebar;