import React from 'react'
import { Button,Modal,Form } from 'react-bootstrap'
import {Redirect} from 'react-router-dom';
import Sidebar  from './Sidebar'
import MessageInbox  from './MessageInbox'
class Dashboard extends React.Component{
    constructor(props){
        super(props);
        
        this.state = { 
         Username:'',
         Password:'',
         memberId:'',
         channelId:'',
         workspaceId:''
        }
      this.handleUserMessges=this.handleUserMessges.bind(this);
      }

      handleUserMessges=(item,workspcId)=>{
        debugger
        this.setState({workspaceId:workspcId})
        if(item.channelId)
        {
          var id=item.channelId.toString();
          this.setState({channelId:id})
          this.setState({memberId:''})
        }
      //  else if(item.workSpaceId)
      //   {
      //     var id=item.workSpaceId.toString();
      //     this.setState({workspaceId:id})
      //     console.log(this.state.workspaceId)
      //     this.setState({memberId:''})
      //     this.setState({channelId:''})
       
      //   }
        else{
          var id=item.memberId.toString();
          this.setState({memberId:id})
          this.setState({channelId:''})
        }
        
              
              }
        

      render(){
        
         return(
           
          <div className="row">
         <div className="col-12" style={{backgroundColor:"#1d1d1d",minHeight : "40px",minWidth:"270px", padding:"0"}}>
         <span style={{float : "right", color:"white",marginRight:"200px", paddingTop:"10px"}}>{localStorage.getItem("memberName")}</span>
           </div>   
         <div className="col-2" style={{backgroundColor:"#1d1d1d",minHeight : "700px",minWidth:"270px", padding:"0"}}>
         <Sidebar workSpaceId={this.state.workspaceId} handleUserMessges={this.handleUserMessges} ></Sidebar>
         </div>
         <div  className="col-8">
          <MessageInbox workSpaceId={this.state.workspaceId} channelId={this.state.channelId}  memberId={this.state.memberId }></MessageInbox>
          </div>
          </div>
         )
         }
    }
    export default Dashboard;