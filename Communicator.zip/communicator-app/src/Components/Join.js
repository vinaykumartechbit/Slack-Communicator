import React from 'react'

import { Button,Modal,Form } from 'react-bootstrap'
import {br} from 'react-router-dom';
class Join extends React.Component{
   
    constructor(props){
        super(props);
       
        this.state = { 
          MemberName:'',
         Email:'',
         Username:'',
         Password:'',
         MobileNumber:'',
         errors:'',
         WorkSpaceId:''
        }
      
      }

      componentDidMount() {
    debugger;
    var url_string = window.location;
var url = new URL(url_string);
var name = url.searchParams.get("email");  
var workspaceid=url.searchParams.get("workspaceid");  
console.log(name);
this.setState({Email:name})
this.setState({WorkSpaceId:workspaceid})
    }


    handleValidation()
    {debugger
        let errors = {};
        let formIsValid = true;
        if(this.state.Username=="" || this.state.Username==undefined)
        { 

        errors["Username"] = "Username  Cannot be empty";
        formIsValid=false;
    
        if(this.state.MemberName=="" || this.state.MemberName==undefined)
        { 

        errors["MemberName"] = "Member Name  Cannot be empty";
        formIsValid=false;
    
        }
        }
        if(this.state.Password=="" || this.state.Password==undefined)
        { 

        errors["Password"] = "Password  Cannot be empty";
        formIsValid=false;
      
        }
        this.setState({errors: errors});
        return formIsValid;
    }
    Reset()
    {
        this.setState({Username:''});
        this.setState({Password:''});
        this.setState({MobileNumber:''});
    }
    handleChange = event => {
        debugger
             this.setState({ [event.target.name]: event.target.value });
           
           };
    handleSubmit(e)
    {
      e.preventDefault();
      if(this.handleValidation())
      {
        debugger
      var body={
          MemberName:this.state.MemberName,
          Username:this.state.Username,
          Password:this.state.Password,
          Email:this.state.Email,
          IsActive:true,
          MobileNumber:this.state.MobileNumber,
          WorkSpaceId:this.state.WorkSpaceId
        }
        
      fetch("https://localhost:44364/api/Members/SaveMembers", {
          method: 'POST',
          headers: { 'Content-Type': 'application/json; charset=utf-8'},
          body: JSON.stringify(body),
      }).then(res => res.json())
      .then((data) => {
        debugger
    
        if(data!=null)
        { 
localStorage.setItem("memberId",data[0].memberId);
          window.location.href="http://localhost:3000/dashboard"
        }
      })
      .catch(console.log)
    }
    }
      render(){
        debugger
         return(
          <div>
           <div className="wrapper fadeInDown">
   <div id="formContent">
     <form>
         
       <input  type="text"  className="fadeIn second" value={this.state.Username}  onChange={this.handleChange}  name="Username" placeholder="username"/>
       <span style={{color: "red"}}>{this.state.errors["Username"]}</span>
       <input  type="text"  style={{color: "red"}} className="fadeIn third" onChange={this.handleChange} value={this.state.Password} name="Password" placeholder="password"/>
       <span style={{color: "red"}}>{this.state.errors["Password"]}</span>
       <input type="text"  className="fadeIn third" onChange={this.handleChange} value={this.state.MemberName} name="MemberName" placeholder="Member Name"/>
       <span style={{color: "red"}}>{this.state.errors["MemberName"]}</span>
       <input type="text"  disabled className="fadeIn second" value={this.state.Email}    name="Email" placeholder="Email"/>
       <input type="text"  className="fadeIn third" onChange={this.handleChange} value={this.state.MobileNumber} name="MobileNumber" placeholder="MobileNumber"/>
      
       <button onClick={(e) => this.handleSubmit(e)} type="button" class="btn btn-primary">Submit</button>
       
       <button onClick={(e) => this.Reset()} type="button"  class="btn btn-primary">Reset</button>
     </form>
 
 
   
 
   </div>
 </div>
          </div>
         )
         }
   }
    export default Join;