﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using CommunicatorEmailService.DataBase.Entities;
using CommunicatorService.DataBase.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CommunicatorEmailService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {

        CommunicatorEmailContext _db;

        public EmailController(CommunicatorEmailContext communicatorContext)
        {
            _db = communicatorContext;
        }
        // GET: api/Email
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Email/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Email
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/Email/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        public async Task<string> SendEmail()
        {
            string body = "";
            string a = string.Empty;
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<EmailModel>(body);

                Members Sender = (from workspc in _db.Members.Where(p => p.MemberId.Equals(Convert.ToInt32(data.SenderId)))
                                  select new Members
                                  {
                                      MemberName = workspc.MemberName

                                  }).FirstOrDefault();

                Workspace workspace = (from workspc in _db.Workspace.Where(p => p.WorkSpaceId.Equals(Convert.ToInt32(data.WorkSpaceId)))
                                       select new Workspace
                                       {
                                           WorkSpaceName = workspc.WorkSpaceName

                                       }).FirstOrDefault();

                a = (from mem in _db.Members
                     join wfm in _db.WorkSpaceForMember on mem.MemberId equals wfm.MemberId
                     where mem.Email.Equals(data.Email) && wfm.WorkSpaceId.Equals(data.WorkSpaceId)
                     select
                     mem.MemberName).FirstOrDefault();

                if (string.IsNullOrEmpty(a))
                {
                    /* SEND MAIL  */
                    try
                    {
                        MailMessage mail = new MailMessage();
                        mail.To.Add(data.Email);


                        mail.From = new MailAddress("vinaykumar.techbitsolution@gmail.com");
                        mail.Subject = "Invitation Link";
                        string Url = "http://localhost:3000/Join?email=";
                        string htmlString = "<html>" +
                      "<body>" +
                     " <p> Hi " + Sender.MemberName + " sent you an invite to join " + workspace.WorkSpaceName + " on Communicator platform</p>" +
                     " <a href=" + Url + "" + data.Email + "&&workspaceid=" + data.WorkSpaceId + ">Join Communicator</a>" +
                      "</body>" +
                      "</html>";


                        mail.Body = htmlString;
                        mail.IsBodyHtml = true;
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                        smtp.Credentials = new System.Net.NetworkCredential
                             ("vinaykumar.techbitsolution@gmail.com", "vinay@2017$%");
                        //Or your Smtp Email ID and Password
                        smtp.EnableSsl = true;
                        smtp.Send(mail);


                        /*    MailMessage message = new MailMessage();


                            message.Subject = "Sending Email with HTML Body";


                            message.IsBodyHtml = true;
                            SmtpClient smtp = new SmtpClient();
                            smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                            smtp.Credentials = new System.Net.NetworkCredential
                                 ("vinaykumar.techbitsolution@gmail.com", "vinay@2017$%");
                            //Or your Smtp Email ID and Password
                            smtp.EnableSsl = true;
                            smtp.Send(message); */


                    }
                    catch (Exception ex)
                    {

                    }


                    /* SEND MAIL ENDS HERE  */
                    a = null;
                }

                return a;
            }

        }


        // POST: api/Members
        [HttpPost]

        public async Task<Members> SaveMembers()
        {
            var id = 0;
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {

                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<MembersModel>(body);

                var chkEmailExists = _db.Members.Where(p => p.Email.Equals(data.Email)).ToList();

                if (chkEmailExists.Count > 0)
                {
                    id = chkEmailExists.First().MemberId;
                    return null;
                }
                else
                {
                    Members members = new Members();
                    members.MemberName = data.MemberName;
                    members.UserName = data.UserName;
                    members.MobileNumber = data.MobileNumber;
                    members.IsActive = data.IsActive;
                    members.Email = data.Email;
                    members.Password = data.Password;
                    members.IsLoggedIn = false;
                    _db.Add(members);
                    _db.SaveChanges();
                    id = members.MemberId;
                }

                var workspaceExists = _db.Workspace.Where(p => p.WorkSpaceId.Equals(data.WorkSpaceId)).ToList();
                if (workspaceExists.Count > 0)
                {
                    var chkWorkspaceForMember = _db.WorkSpaceForMember.Where(p => p.MemberId.Equals(id) && p.WorkSpaceId.Equals(data.WorkSpaceId)).ToList();

                    if (chkWorkspaceForMember.Count > 0)
                    {
                        return null;
                    }
                    else
                    {
                        try
                        {
                            WorkSpaceForMembers workSpaceForMembers = new WorkSpaceForMembers();
                            workSpaceForMembers.MemberId = id;
                            workSpaceForMembers.WorkSpaceId = data.WorkSpaceId;
                            workSpaceForMembers.IsActive = true;
                            _db.Add(workSpaceForMembers);
                            _db.SaveChanges();
                        }
                        catch (Exception ex)
                        {

                            throw;
                        }

                    }

                }
                return null;
            }
        }

    }
}
