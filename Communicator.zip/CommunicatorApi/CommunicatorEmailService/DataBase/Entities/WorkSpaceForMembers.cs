﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommunicatorService.DataBase.Entities
{
    public class WorkSpaceForMembers
    {
        public int workspaceformembersid { get; set; }
        public int MemberId { get; set; }
        public int WorkSpaceId { get; set; }
        public bool IsActive { get; set; }
    }
}
