﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommunicatorService.DataBase.Entities
{
    public class EmailModel
    {
        public string Email { get; set; }
        public string WorkSpaceId { get; set; }

        public string SenderId { get; set; }
    }
}
