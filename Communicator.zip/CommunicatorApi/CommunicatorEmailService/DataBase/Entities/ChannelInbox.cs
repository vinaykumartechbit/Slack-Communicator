﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CommunicatorService.DataBase.Entities
{
    public class ChannelInbox
    { 
        [Key]
        public int ChannelInboxId { get; set; }
      
        public string Message { get; set; }

        public int SentBy { get; set; }
        public int WorkSpaceid { get; set; }
        public int SentTo { get; set; }
        public DateTime SentDate { get; set; }


    }
}
