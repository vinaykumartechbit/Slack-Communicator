﻿using CommunicatorService.DataBase.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommunicatorEmailService.DataBase.Entities
{
    public class CommunicatorEmailContext  :DbContext
    {
        public DbSet<Channels> Channels { get; set; }
        public DbSet<Members> Members { get; set; }
        public DbSet<MembersInbox> MembersInbox { get; set; }
        public DbSet<ChannelInbox> ChannelInbox { get; set; }
        public DbSet<WorkSpaceForMembers> WorkSpaceForMember { get; set; }
        public DbSet<Workspace> Workspace { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(@"User ID =StickyUser;Password=123;Server=localhost;Port=5432;Database=CommunicatorApp;Integrated Security = true; Pooling = true;");

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
        public override int SaveChanges()
        {
            ChangeTracker.DetectChanges();
            return base.SaveChanges();
        }
    }
}
