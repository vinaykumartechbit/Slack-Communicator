﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommunicatorService.DataBase.Entities
{
    public class Workspace
    {
        public int WorkSpaceId { get; set; }

        public string WorkSpaceName { get; set; }

      public DateTime CreateDate { get; set; }
    }
}
