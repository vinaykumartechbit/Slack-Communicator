﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommunicatorService.DataBase.Entities
{
    public class WorkSpaceModel
    {
        public int WorkSpaceId { get; set; }

        public string WorkSpaceName { get; set; }

        public DateTime CreateDate { get; set; }

        public List<Channels> ChannelItems { get; set; }

        public List<Members> MemberItems { get; set; }
    }
}
