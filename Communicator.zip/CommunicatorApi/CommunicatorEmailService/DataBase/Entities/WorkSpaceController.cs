﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using CommunicatorEmailService.DataBase.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;


namespace CommunicatorService.DataBase.Entities
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class WorkSpaceController : ControllerBase
    {

        CommunicatorEmailContext _db;

        public WorkSpaceController(CommunicatorEmailContext communicatorContext)
        {
            _db = communicatorContext;
        }
        // GET: api/WorkSpace
        [HttpGet]
        public List<WorkSpaceModel> GetWorkSpace()
        {
            List<WorkSpaceModel> Workspacelist = new List<WorkSpaceModel>();

            try
            {
                Workspacelist = (from workspc in _db.Workspace
                                 select new WorkSpaceModel
                                 {
                                     WorkSpaceId = workspc.WorkSpaceId,
                                     WorkSpaceName = workspc.WorkSpaceName,

                                 }).ToList();


                for (int i = 0; i < Workspacelist.Count; i++)
                {
                    Workspacelist[i].ChannelItems = (from workspc in _db.Channels
                                                     where workspc.WorkSpaceId.Equals(Workspacelist[i].WorkSpaceId)
                                                     select new Channels
                                                     {
                                                         ChannelId = workspc.ChannelId,
                                                         ChannelName = workspc.ChannelName,

                                                     }).ToList();


                    Workspacelist[i].MemberItems = (from workspc in _db.Members
                                                    join wfm in _db.WorkSpaceForMember on workspc.MemberId equals wfm.MemberId
                                                    where wfm.WorkSpaceId.Equals(Workspacelist[i].WorkSpaceId)
                                                    select new Members
                                                    {
                                                        MemberId = workspc.MemberId,
                                                        MemberName = workspc.MemberName,

                                                    }).ToList();
                }
            }
            catch (Exception ex)
            {

                throw;
            }



            return Workspacelist;
        }


        [HttpPost]

        public async Task<List<Workspace>> SaveWorkSpace()
        {
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<Workspace>(body);

                Workspace workspace = new Workspace();
                workspace.WorkSpaceName = data.WorkSpaceName;
                workspace.CreateDate = DateTime.Now;

                _db.Workspace.Add(workspace);
                _db.SaveChanges();

                return _db.Workspace.ToList();
            }

        }
      



    } 
}
