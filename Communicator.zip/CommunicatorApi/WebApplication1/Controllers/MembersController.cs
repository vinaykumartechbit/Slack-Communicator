﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CommunicatorService.DataBase.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StickyGetService.DataBase.Entities;

namespace CommunicatorService.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class MembersController : ControllerBase
    {
       
        CommunicatorContext _db;

        public MembersController(CommunicatorContext communicatorContext)
        {
            _db = communicatorContext;
        }
        // GET: api/Members
        [HttpGet]
      
        public List<WorkSpaceForMembers> Get()
        {

            /*string connectionString = "Server=127.0.0.1;Port=6000;User Id=postgres; Password=123; Database=postgres; CommandTimeout=120;"; 
            var connection = new Npgsql.NpgsqlConnection(connectionString); 
            connection.Open();*/
            return _db.WorkSpaceForMember.ToList();
        }

        // GET: api/Members/5
        [HttpGet("{id}", Name = "Get")]
      
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Members
        [HttpPost]

        public async Task<Members> SaveMembers()
        {
            var id = 0;
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {

                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<MembersModel>(body);

                var chkEmailExists = _db.Members.Where(p => p.Email.Equals(data.Email)).ToList();

                if (chkEmailExists.Count > 0)
                {
                    id = chkEmailExists.First().MemberId;
                    return null;
                }
                else
                {
                    Members members = new Members();
                    members.MemberName = data.MemberName;
                    members.UserName = data.UserName;
                    members.MobileNumber = data.MobileNumber;
                    members.IsActive = data.IsActive;
                    members.Email = data.Email;
                    members.Password = data.Password;
                    members.IsLoggedIn = false;
                    _db.Add(members);
                    _db.SaveChanges();
                    id = members.MemberId;
                }

                var workspaceExists = _db.Workspace.Where(p => p.WorkSpaceId.Equals(data.WorkSpaceId)).ToList();
                if (workspaceExists.Count > 0)
                {
                    var chkWorkspaceForMember = _db.WorkSpaceForMember.Where(p => p.MemberId.Equals(id) && p.WorkSpaceId.Equals(data.WorkSpaceId)).ToList();

                    if (chkWorkspaceForMember.Count > 0)
                    {
                        return null;
                    }
                    else
                    {
                        try
                        {
                            WorkSpaceForMembers workSpaceForMembers = new WorkSpaceForMembers();
                            workSpaceForMembers.MemberId = id;
                            workSpaceForMembers.WorkSpaceId = data.WorkSpaceId;
                            workSpaceForMembers.IsActive = true;
                            _db.Add(workSpaceForMembers);
                            _db.SaveChanges();
                        }
                        catch (Exception ex)
                        {

                            throw;
                        }
                       
                    }

                }
                return null;
            }
        }


        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
   
        public void Delete(int id)
        {
        }

        [HttpPost]
      
        public async Task<List<Members>> Login()
        {
            List<Members> obj = new List<Members>();
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<Members>(body);

               obj= _db.Members.Where(p => p.UserName.Equals(data.UserName) && p.Password.Equals(data.Password) && p.IsActive.Equals(true)).ToList();
                if(obj.Count>0)
                {
                    
                    
                    var id = _db.Members.Find(obj.First().MemberId);
                    id.IsLoggedIn = true;
                    _db.Entry(id).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _db.SaveChanges();
                     
                }
            }
            return obj;
        }
       
    }
}
