﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CommunicatorService.DataBase.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Npgsql;
using StickyGetService.DataBase.Entities;

namespace CommunicatorService.Controllers
{
    
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class MembersInboxController : ControllerBase
    {
        CommunicatorContext _db;

        public MembersInboxController(CommunicatorContext communicatorContext)
        {
            _db = communicatorContext; 
        }
        // GET: api/MembersInbox
        [HttpGet]
      
        public List<ChannelInbox> GetMembersInbox()
        {
            return _db.ChannelInbox.ToList();
        }

        [HttpPost]

        public async Task<List<MemberInboxModel>> SaveMessages()
        {
            string body = "";
            List<MemberInboxModel> list = new List<MemberInboxModel>();
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<MemberInboxModel>(body);
                if(data.MsgSource=="channel")
                {
                    ChannelInbox channelInbox = new ChannelInbox();
                    channelInbox.Message = data.Message;
                    channelInbox.SentBy = data.SentBy;
                    channelInbox.SentTo = data.SentTo;
                    channelInbox.SentDate = DateTime.Now;
                    channelInbox.WorkSpaceid = data.WorkSpaceId;
                    _db.ChannelInbox.Add(channelInbox);
                    _db.SaveChanges();
                }
                else
                {
                    MembersInbox membersInbox = new MembersInbox();
                    membersInbox.Message = data.Message;
                    membersInbox.SentBy = data.SentBy;
                    membersInbox.SentTo = data.SentTo;
                    membersInbox.SentDate = DateTime.Now;
                    membersInbox.WorkSpaceId = data.WorkSpaceId;
                    _db.MembersInbox.Add(membersInbox);
                    _db.SaveChanges();
                }
               
                return list;
            }
                
        }

        [HttpPost]
        
        public async Task<List<MemberInboxModel>> GetMessages()
        {
            string body = "";
            List<MemberInboxModel> list = new List<MemberInboxModel>();
            using (StreamReader stream = new StreamReader(Request.Body))
            {

                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<MemberInboxModel>(body);

                if (data.MsgSource == "channel")
                {
                    var l = _db.ChannelInbox.ToList().Where(p=>p.SentTo.Equals(data.SentTo)).ToList();

                     list = (from MemInb in _db.ChannelInbox
                                join Mem in _db.Channels
                                on MemInb.SentTo equals Mem.ChannelId
                                where MemInb.SentTo.Equals(data.SentTo)
                             // where(p => (p.SentBy.Equals(data.SentBy) && p.SentTo.Equals(data.SentTo)) || (p.SentBy.Equals(data.SentTo) && p.SentTo.Equals(data.SentBy)))
                             orderby MemInb.SentDate ascending
                             select new MemberInboxModel
                                {

                                    SenderName = _db.Members.Where(p => p.MemberId.Equals(MemInb.SentBy)).Select(u => u.MemberName).SingleOrDefault(),
                                    RecieverName = _db.Members.Where(p => p.MemberId.Equals(MemInb.SentTo)).Select(u => u.MemberName).SingleOrDefault(),
                                    Message = MemInb.Message,
                                    SentDate = MemInb.SentDate
                                }).ToList();
                  
                  

                     }
                else
                {

                    list = (from MemInb in _db.MembersInbox
                            join Mem in _db.Members
                            on MemInb.SentTo equals Mem.MemberId
                            where (MemInb.SentBy.Equals(data.SentBy) && MemInb.SentTo.Equals(data.SentTo)) || (MemInb.SentBy.Equals(data.SentTo) && MemInb.SentTo.Equals(data.SentBy))
                            // where(p => (p.SentBy.Equals(data.SentBy) && p.SentTo.Equals(data.SentTo)) || (p.SentBy.Equals(data.SentTo) && p.SentTo.Equals(data.SentBy)))
                          orderby MemInb.SentDate ascending
                            select new MemberInboxModel
                            {

                                SenderName = _db.Members.Where(p => p.MemberId.Equals(MemInb.SentBy)).Select(u => u.MemberName).SingleOrDefault(),
                                RecieverName = _db.Members.Where(p => p.MemberId.Equals(MemInb.SentTo)).Select(u => u.MemberName).SingleOrDefault(),
                                Message = MemInb.Message,
                                SentDate = MemInb.SentDate
                            }).ToList();
                  
                
                }
                // var list=  _db.MembersInbox.Where(p => (p.SentBy.Equals(data.SentBy) && p.SentTo.Equals(data.SentTo)) || (p.SentBy.Equals(data.SentTo) && p.SentTo.Equals(data.SentBy))).ToList();
              
               
            }

            DateTime? date = null;
            foreach (var ListItem in list)
            {
                if (!date.HasValue)
                {
                    ListItem.MessageDate = ListItem.SentDate.Date.ToString();
                }
                else if ( date.Value.Date != ListItem.SentDate.Date)
                {
                    ListItem.MessageDate = ListItem.SentDate.Date.ToString();
                }

                date = ListItem.SentDate;
            }


            return list;
        }



    }
}
