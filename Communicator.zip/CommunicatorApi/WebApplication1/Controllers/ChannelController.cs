﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CommunicatorService.DataBase.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StickyGetService.DataBase.Entities;

namespace CommunicatorService.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ChannelController : ControllerBase
    {
        CommunicatorContext _db;
        public ChannelController(CommunicatorContext communicatorContext)
        {
            _db = communicatorContext;
        }
        // GET: api/Channel
        [HttpPost]
        public async  Task<List<Channels>> GetChannel()
        {
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<Channels>(body);
                return _db.Channels.Where(p=>p.WorkSpaceId.Equals(data.WorkSpaceId)).ToList();
            }
        }

       

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        [HttpPost]

        public async Task<List<Channels>> SaveChannel()
            {
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<Channels>(body);
                Channels channel = new Channels();
                channel.ChannelName = data.ChannelName;
                channel.MemberList = data.MemberList;
                channel.WorkSpaceId = data.WorkSpaceId;
                _db.Channels.Add(channel);
                _db.SaveChanges();
                return _db.Channels.ToList();
            }
            return null;
        }
    }
}
