﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StickyGetService.DataBase.Entities;

namespace CommunicatorService.DataBase.Entities
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class WorkSpaceController : ControllerBase
    {

        CommunicatorContext _db;

        public WorkSpaceController(CommunicatorContext communicatorContext)
        {
            _db = communicatorContext;
        }
        // GET: api/WorkSpace
        [HttpGet]
        public List<WorkSpaceModel> GetWorkSpace()
        {
            List<WorkSpaceModel> Workspacelist = new List<WorkSpaceModel>();

            try
            {
               Workspacelist = (from workspc in _db.Workspace
                                                      select new WorkSpaceModel
                                                      {
                                                          WorkSpaceId = workspc.WorkSpaceId,
                                                          WorkSpaceName = workspc.WorkSpaceName,

                                                      }).ToList();


                for (int i = 0; i < Workspacelist.Count; i++)
                {
                    Workspacelist[i].ChannelItems = (from workspc in _db.Channels
                                                     where workspc.WorkSpaceId.Equals(Workspacelist[i].WorkSpaceId)
                                                     select new Channels
                                                     {
                                                         ChannelId = workspc.ChannelId,
                                                         ChannelName = workspc.ChannelName,

                                                     }).ToList();


                    Workspacelist[i].MemberItems = (from workspc in _db.Members
                                                    join wfm in _db.WorkSpaceForMember on workspc.MemberId equals wfm.MemberId
                                                    where wfm.WorkSpaceId.Equals(Workspacelist[i].WorkSpaceId)
                                                    select new Members
                                                    {
                                                        MemberId = workspc.MemberId,
                                                        MemberName = workspc.MemberName,

                                                    }).ToList();
                } 
            }
            catch (Exception ex)
            {

                throw;
            }

           
            
            return Workspacelist;
        }


        [HttpPost]

        public async Task<List<Workspace>> SaveWorkSpace()
        {
            string body = "";
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<Workspace>(body);
                
                Workspace workspace = new Workspace();
                workspace.WorkSpaceName = data.WorkSpaceName;
                workspace.CreateDate = DateTime.Now;

                    _db.Workspace.Add(workspace);
                    _db.SaveChanges();

                return _db.Workspace.ToList();
            }

        }
        [HttpPost]

        public async Task<string> SendEmail()
        {
            string body = "";
            string a = string.Empty;
            using (StreamReader stream = new StreamReader(Request.Body))
            {
                body = await stream.ReadToEndAsync();
                var data = JsonConvert.DeserializeObject<EmailModel>(body);

                Members Sender = (from workspc in _db.Members.Where(p => p.MemberId.Equals(Convert.ToInt32(data.SenderId)))
                                     select new Members
                                     {
                                         MemberName = workspc.MemberName

                                     }).FirstOrDefault();

                Workspace workspace = (from workspc in _db.Workspace.Where(p => p.WorkSpaceId.Equals(Convert.ToInt32(data.WorkSpaceId)))
                                           select new Workspace
                                           {
                                               WorkSpaceName = workspc.WorkSpaceName

                                           }).FirstOrDefault();

                a = (from mem in _db.Members
                     join wfm in _db.WorkSpaceForMember on mem.MemberId equals wfm.MemberId
                     where mem.Email.Equals(data.Email) && wfm.WorkSpaceId.Equals(data.WorkSpaceId)
                     select
                     mem.MemberName).FirstOrDefault();

                if (string.IsNullOrEmpty(a))
                {
                    /* SEND MAIL  */
                    try
                    {
                        MailMessage mail = new MailMessage();
                        mail.To.Add(data.Email);
                    

                        mail.From = new MailAddress("vinaykumar.techbitsolution@gmail.com");
                        mail.Subject = "Invitation Link";
                        string Url = "http://localhost:3000/Join?email=";
                        string htmlString = "<html>" +
                      "<body>" +
                     " <p> Hi "+ Sender.MemberName+" sent you an invite to join " + workspace.WorkSpaceName+ " on Communicator platform</p>" +
                     " <a href="+ Url + ""+data.Email+"&&workspaceid="+data.WorkSpaceId+">Join Communicator</a>" +
                      "</body>" +
                      "</html>";
                   

                        mail.Body = htmlString;
                        mail.IsBodyHtml = true;
                           SmtpClient smtp = new SmtpClient();
                           smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                           smtp.Credentials = new System.Net.NetworkCredential
                                ("vinaykumar.techbitsolution@gmail.com", "vinay@2017$%");
                           //Or your Smtp Email ID and Password
                           smtp.EnableSsl = true;
                           smtp.Send(mail);

                      
                    /*    MailMessage message = new MailMessage();

                      
                        message.Subject = "Sending Email with HTML Body";
                       

                        message.IsBodyHtml = true;
                        SmtpClient smtp = new SmtpClient();
                        smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                        smtp.Credentials = new System.Net.NetworkCredential
                             ("vinaykumar.techbitsolution@gmail.com", "vinay@2017$%");
                        //Or your Smtp Email ID and Password
                        smtp.EnableSsl = true;
                        smtp.Send(message); */


                    }
                    catch (Exception ex)
                    {
                       
                    }


                    /* SEND MAIL ENDS HERE  */
                    a = null;
                }

                return a;
            }

        }

    }
}
