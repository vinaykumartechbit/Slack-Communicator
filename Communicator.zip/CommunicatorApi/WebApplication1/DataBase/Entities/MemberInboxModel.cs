﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CommunicatorService.DataBase.Entities
{
    public class MemberInboxModel
    {
        public int MembersInboxId { get; set; }

        public string Message { get; set; }

        public string SenderName { get; set; }
        public int WorkSpaceId { get; set; }
        public int ChannelId { get; set; }
        public string RecieverName { get; set; }

        public int SentBy { get; set; }

        public int SentTo { get; set; }
        public DateTime SentDate { get; set; }
        public string MsgSource { get; set; }

        public string MessageDate { get; set; }
    }
}
